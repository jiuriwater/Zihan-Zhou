To compile on feng-linux / feng-gps:

module add legacy-eng
module add qt/5.13.0
qmake -project QT+=opengl
qmake
make

1.To run the qt, use command:
./LoopSubdivisionRelease ../LoopSubdivisionRelease/diredgenormals/"name".diredgenormal

"name" is the file to open, for instance, to open cube.diredgenormal use command:
./LoopSubdivisionRelease ../LoopSubdivisionRelease/diredgenormals/cube.diredgenormal

then enter the times for LoopSubdivision.

2.the new .diredgenormal file will be created as "name_new".diredgenormal.
for cube.diredgenormal will be cube_new.diredgenormal.


